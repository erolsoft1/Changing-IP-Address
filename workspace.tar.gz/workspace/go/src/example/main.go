package main

import (
	"fmt"
	"math/rand"
	"os/exec"
	"time"
)

// Renkli metinler için renk kodları
const (
	Reset  = "\033[0m"
	Red    = "\033[31m"
	Green  = "\033[32m"
	Yellow = "\033[33m"
)

func main() {
	// Rastgele sayı üreteci için tohumu ayarla
	rand.Seed(time.Now().UnixNano())

	// Sonsuz döngü
	for {
		// Figlet ile "Changing IP address" yazısını oluştur
		cmd := exec.Command("figlet", "-f", "big", "Changing IP Address")
		output, _ := cmd.Output()

		// Temizleme işlemi
		fmt.Print("\033[H\033[2J")

		// Figlet çıktısını renklendir ve yazdır
		fmt.Printf("%s%s%s\n", Yellow, string(output), Reset)

		// 6 IP adresini dakikada bir değiştir
		for i := 0; i < 6; i++ {
			// Geçerli zamanı al ve biçimlendir
			currentTime := time.Now().Format("2006-01-02 15:04:05")

			// Rastgele bir IP adresi seç
			ip := generateRandomIP()

			// Rastgele bir renk seç
			colors := []string{Red, Green, Yellow}
			color := colors[rand.Intn(len(colors))]

			// Figlet çıktısını renklendir ve yazdır
			fmt.Printf("[%s] %s%s%s\n", currentTime, color, ip, Reset)

			// Bir sonraki IP adresini değiştirmeden önce 10 saniye bekle
			time.Sleep(10 * time.Second)
		}

		// Bir sonraki grup işlem başlamadan önce 1 dakika bekle
		time.Sleep(1 * time.Minute)
	}
}

// Rastgele bir IP adresi oluştur
func generateRandomIP() string {
	return fmt.Sprintf("%d.%d.%d.%d", rand.Intn(256), rand.Intn(256), rand.Intn(256), rand.Intn(256))
}

